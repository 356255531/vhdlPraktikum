/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/ISEWorkspace/IDEA1/IDEA1/IDEA1/mulop.vhd";
extern char *IEEE_P_3620187407;
extern char *IEEE_P_2592010699;

unsigned char ieee_p_3620187407_sub_2546418145_3965413181(char *, char *, char *, int );
unsigned char ieee_p_3620187407_sub_4060537613_3965413181(char *, char *, char *, char *, char *);
char *ieee_p_3620187407_sub_436279890_3965413181(char *, char *, char *, char *, int );
char *ieee_p_3620187407_sub_767632659_3965413181(char *, char *, char *, char *, char *, char *);
char *ieee_p_3620187407_sub_767740470_3965413181(char *, char *, char *, char *, char *, char *);


static void work_a_3400501926_3212880686_p_0(char *t0)
{
    char t7[16];
    char t9[16];
    char t21[16];
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t8;
    char *t10;
    char *t11;
    int t12;
    unsigned int t13;
    char *t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;
    char *t19;
    char *t20;

LAB0:    xsi_set_current_line(47, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 5692U);
    t3 = ieee_p_3620187407_sub_2546418145_3965413181(IEEE_P_3620187407, t2, t1, 0);
    if (t3 != 0)
        goto LAB2;

LAB4:    xsi_set_current_line(47, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t4 = ((IEEE_P_2592010699) + 4024);
    t5 = (t0 + 5692U);
    t1 = xsi_base_array_concat(t1, t7, t4, (char)99, (unsigned char)2, (char)97, t2, t5, (char)101);
    t6 = (t0 + 1648U);
    t8 = *((char **)t6);
    t6 = (t8 + 0);
    t13 = (1U + 16U);
    memcpy(t6, t1, t13);

LAB3:    xsi_set_current_line(48, ng0);
    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t1 = (t0 + 5708U);
    t3 = ieee_p_3620187407_sub_2546418145_3965413181(IEEE_P_3620187407, t2, t1, 0);
    if (t3 != 0)
        goto LAB5;

LAB7:    xsi_set_current_line(48, ng0);
    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t4 = ((IEEE_P_2592010699) + 4024);
    t5 = (t0 + 5708U);
    t1 = xsi_base_array_concat(t1, t7, t4, (char)99, (unsigned char)2, (char)97, t2, t5, (char)101);
    t6 = (t0 + 1768U);
    t8 = *((char **)t6);
    t6 = (t8 + 0);
    t13 = (1U + 16U);
    memcpy(t6, t1, t13);

LAB6:    xsi_set_current_line(49, ng0);
    t1 = (t0 + 1648U);
    t2 = *((char **)t1);
    t1 = (t0 + 5740U);
    t4 = (t0 + 1768U);
    t5 = *((char **)t4);
    t4 = (t0 + 5740U);
    t6 = ieee_p_3620187407_sub_767632659_3965413181(IEEE_P_3620187407, t7, t2, t1, t5, t4);
    t8 = (t0 + 2248U);
    t10 = *((char **)t8);
    t8 = (t10 + 0);
    t11 = (t7 + 12U);
    t13 = *((unsigned int *)t11);
    t15 = (1U * t13);
    memcpy(t8, t6, t15);
    xsi_set_current_line(50, ng0);
    t1 = (t0 + 2248U);
    t2 = *((char **)t1);
    t13 = (33 - 32);
    t15 = (t13 * 1U);
    t16 = (0 + t15);
    t1 = (t2 + t16);
    t4 = (t0 + 2008U);
    t5 = *((char **)t4);
    t4 = (t5 + 0);
    memcpy(t4, t1, 17U);
    xsi_set_current_line(51, ng0);
    t1 = (t0 + 2248U);
    t2 = *((char **)t1);
    t13 = (33 - 15);
    t15 = (t13 * 1U);
    t16 = (0 + t15);
    t1 = (t2 + t16);
    t5 = ((IEEE_P_2592010699) + 4024);
    t6 = (t9 + 0U);
    t8 = (t6 + 0U);
    *((int *)t8) = 15;
    t8 = (t6 + 4U);
    *((int *)t8) = 0;
    t8 = (t6 + 8U);
    *((int *)t8) = -1;
    t12 = (0 - 15);
    t17 = (t12 * -1);
    t17 = (t17 + 1);
    t8 = (t6 + 12U);
    *((unsigned int *)t8) = t17;
    t4 = xsi_base_array_concat(t4, t7, t5, (char)99, (unsigned char)2, (char)97, t1, t9, (char)101);
    t8 = (t0 + 1888U);
    t10 = *((char **)t8);
    t8 = (t10 + 0);
    t17 = (1U + 16U);
    memcpy(t8, t4, t17);
    xsi_set_current_line(52, ng0);
    t1 = (t0 + 1888U);
    t2 = *((char **)t1);
    t1 = (t0 + 5756U);
    t4 = (t0 + 2008U);
    t5 = *((char **)t4);
    t4 = (t0 + 5756U);
    t3 = ieee_p_3620187407_sub_4060537613_3965413181(IEEE_P_3620187407, t2, t1, t5, t4);
    if (t3 != 0)
        goto LAB8;

LAB10:    xsi_set_current_line(54, ng0);
    t1 = (t0 + 1888U);
    t2 = *((char **)t1);
    t1 = (t0 + 5756U);
    t4 = (t0 + 2008U);
    t5 = *((char **)t4);
    t4 = (t0 + 5756U);
    t6 = ieee_p_3620187407_sub_767740470_3965413181(IEEE_P_3620187407, t21, t2, t1, t5, t4);
    t8 = (t0 + 2368U);
    t10 = *((char **)t8);
    t12 = *((int *)t10);
    t8 = ieee_p_3620187407_sub_436279890_3965413181(IEEE_P_3620187407, t9, t6, t21, t12);
    t11 = ieee_p_3620187407_sub_436279890_3965413181(IEEE_P_3620187407, t7, t8, t9, 1);
    t14 = (t0 + 2128U);
    t18 = *((char **)t14);
    t14 = (t18 + 0);
    t19 = (t7 + 12U);
    t13 = *((unsigned int *)t19);
    t15 = (1U * t13);
    memcpy(t14, t11, t15);

LAB9:    xsi_set_current_line(56, ng0);
    t1 = (t0 + 2128U);
    t2 = *((char **)t1);
    t13 = (16 - 15);
    t15 = (t13 * 1U);
    t16 = (0 + t15);
    t1 = (t2 + t16);
    t4 = (t0 + 3752);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t10 = *((char **)t8);
    memcpy(t10, t1, 16U);
    xsi_driver_first_trans_fast_port(t4);
    t1 = (t0 + 3672);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(47, ng0);
    t4 = (t0 + 5952);
    t8 = ((IEEE_P_2592010699) + 4024);
    t10 = (t9 + 0U);
    t11 = (t10 + 0U);
    *((int *)t11) = 0;
    t11 = (t10 + 4U);
    *((int *)t11) = 15;
    t11 = (t10 + 8U);
    *((int *)t11) = 1;
    t12 = (15 - 0);
    t13 = (t12 * 1);
    t13 = (t13 + 1);
    t11 = (t10 + 12U);
    *((unsigned int *)t11) = t13;
    t6 = xsi_base_array_concat(t6, t7, t8, (char)99, (unsigned char)3, (char)97, t4, t9, (char)101);
    t11 = (t0 + 1648U);
    t14 = *((char **)t11);
    t11 = (t14 + 0);
    t13 = (1U + 16U);
    memcpy(t11, t6, t13);
    goto LAB3;

LAB5:    xsi_set_current_line(48, ng0);
    t4 = (t0 + 5968);
    t8 = ((IEEE_P_2592010699) + 4024);
    t10 = (t9 + 0U);
    t11 = (t10 + 0U);
    *((int *)t11) = 0;
    t11 = (t10 + 4U);
    *((int *)t11) = 15;
    t11 = (t10 + 8U);
    *((int *)t11) = 1;
    t12 = (15 - 0);
    t13 = (t12 * 1);
    t13 = (t13 + 1);
    t11 = (t10 + 12U);
    *((unsigned int *)t11) = t13;
    t6 = xsi_base_array_concat(t6, t7, t8, (char)99, (unsigned char)3, (char)97, t4, t9, (char)101);
    t11 = (t0 + 1768U);
    t14 = *((char **)t11);
    t11 = (t14 + 0);
    t13 = (1U + 16U);
    memcpy(t11, t6, t13);
    goto LAB6;

LAB8:    xsi_set_current_line(53, ng0);
    t6 = (t0 + 1888U);
    t8 = *((char **)t6);
    t6 = (t0 + 5756U);
    t10 = (t0 + 2008U);
    t11 = *((char **)t10);
    t10 = (t0 + 5756U);
    t14 = ieee_p_3620187407_sub_767740470_3965413181(IEEE_P_3620187407, t7, t8, t6, t11, t10);
    t18 = (t0 + 2128U);
    t19 = *((char **)t18);
    t18 = (t19 + 0);
    t20 = (t7 + 12U);
    t13 = *((unsigned int *)t20);
    t15 = (1U * t13);
    memcpy(t18, t14, t15);
    goto LAB9;

}


extern void work_a_3400501926_3212880686_init()
{
	static char *pe[] = {(void *)work_a_3400501926_3212880686_p_0};
	xsi_register_didat("work_a_3400501926_3212880686", "isim/tb_idea_isim_beh.exe.sim/work/a_3400501926_3212880686.didat");
	xsi_register_executes(pe);
}
