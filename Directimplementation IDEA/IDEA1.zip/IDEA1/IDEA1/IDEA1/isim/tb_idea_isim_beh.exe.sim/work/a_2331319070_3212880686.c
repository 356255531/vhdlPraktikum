/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/ISEWorkspace/IDEA1/IDEA1/IDEA1/keygen.vhd";



static void work_a_2331319070_3212880686_p_0(char *t0)
{
    char *t1;
    char *t2;
    int t3;
    int t4;
    char *t5;
    char *t6;
    int t7;
    int t8;
    char *t9;
    char *t10;
    int t11;
    unsigned char t12;
    char *t13;
    int t14;
    int t15;
    char *t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    int t20;
    unsigned int t21;
    unsigned int t22;
    int t23;
    int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;

LAB0:    xsi_set_current_line(48, ng0);
    t1 = (t0 + 2768U);
    t2 = *((char **)t1);
    t1 = (t2 + 0);
    *((int *)t1) = 127;
    xsi_set_current_line(48, ng0);
    t1 = (t0 + 2888U);
    t2 = *((char **)t1);
    t1 = (t2 + 0);
    *((int *)t1) = 0;
    xsi_set_current_line(49, ng0);
    t1 = (t0 + 8692);
    *((int *)t1) = 7;
    t2 = (t0 + 8696);
    *((int *)t2) = 0;
    t3 = 7;
    t4 = 0;

LAB2:    if (t3 >= t4)
        goto LAB3;

LAB5:    xsi_set_current_line(58, ng0);
    t1 = (t0 + 8708);
    *((int *)t1) = 63;
    t2 = (t0 + 8712);
    *((int *)t2) = 0;
    t3 = 63;
    t4 = 0;

LAB18:    if (t3 >= t4)
        goto LAB19;

LAB21:    xsi_set_current_line(65, ng0);
    t1 = (t0 + 3008U);
    t2 = *((char **)t1);
    t3 = (7 - 7);
    t17 = (t3 * -1);
    t18 = (96U * t17);
    t19 = (0 + t18);
    t1 = (t2 + t19);
    t5 = (t0 + 4512);
    t6 = (t5 + 56U);
    t9 = *((char **)t6);
    t10 = (t9 + 56U);
    t13 = *((char **)t10);
    memcpy(t13, t1, 96U);
    xsi_driver_first_trans_fast_port(t5);
    xsi_set_current_line(65, ng0);
    t1 = (t0 + 3008U);
    t2 = *((char **)t1);
    t3 = (6 - 7);
    t17 = (t3 * -1);
    t18 = (96U * t17);
    t19 = (0 + t18);
    t1 = (t2 + t19);
    t5 = (t0 + 4576);
    t6 = (t5 + 56U);
    t9 = *((char **)t6);
    t10 = (t9 + 56U);
    t13 = *((char **)t10);
    memcpy(t13, t1, 96U);
    xsi_driver_first_trans_fast_port(t5);
    xsi_set_current_line(65, ng0);
    t1 = (t0 + 3008U);
    t2 = *((char **)t1);
    t3 = (5 - 7);
    t17 = (t3 * -1);
    t18 = (96U * t17);
    t19 = (0 + t18);
    t1 = (t2 + t19);
    t5 = (t0 + 4640);
    t6 = (t5 + 56U);
    t9 = *((char **)t6);
    t10 = (t9 + 56U);
    t13 = *((char **)t10);
    memcpy(t13, t1, 96U);
    xsi_driver_first_trans_fast_port(t5);
    xsi_set_current_line(65, ng0);
    t1 = (t0 + 3008U);
    t2 = *((char **)t1);
    t3 = (4 - 7);
    t17 = (t3 * -1);
    t18 = (96U * t17);
    t19 = (0 + t18);
    t1 = (t2 + t19);
    t5 = (t0 + 4704);
    t6 = (t5 + 56U);
    t9 = *((char **)t6);
    t10 = (t9 + 56U);
    t13 = *((char **)t10);
    memcpy(t13, t1, 96U);
    xsi_driver_first_trans_fast_port(t5);
    xsi_set_current_line(65, ng0);
    t1 = (t0 + 3008U);
    t2 = *((char **)t1);
    t3 = (3 - 7);
    t17 = (t3 * -1);
    t18 = (96U * t17);
    t19 = (0 + t18);
    t1 = (t2 + t19);
    t5 = (t0 + 4768);
    t6 = (t5 + 56U);
    t9 = *((char **)t6);
    t10 = (t9 + 56U);
    t13 = *((char **)t10);
    memcpy(t13, t1, 96U);
    xsi_driver_first_trans_fast_port(t5);
    xsi_set_current_line(65, ng0);
    t1 = (t0 + 3008U);
    t2 = *((char **)t1);
    t3 = (2 - 7);
    t17 = (t3 * -1);
    t18 = (96U * t17);
    t19 = (0 + t18);
    t1 = (t2 + t19);
    t5 = (t0 + 4832);
    t6 = (t5 + 56U);
    t9 = *((char **)t6);
    t10 = (t9 + 56U);
    t13 = *((char **)t10);
    memcpy(t13, t1, 96U);
    xsi_driver_first_trans_fast_port(t5);
    xsi_set_current_line(65, ng0);
    t1 = (t0 + 3008U);
    t2 = *((char **)t1);
    t3 = (1 - 7);
    t17 = (t3 * -1);
    t18 = (96U * t17);
    t19 = (0 + t18);
    t1 = (t2 + t19);
    t5 = (t0 + 4896);
    t6 = (t5 + 56U);
    t9 = *((char **)t6);
    t10 = (t9 + 56U);
    t13 = *((char **)t10);
    memcpy(t13, t1, 96U);
    xsi_driver_first_trans_fast_port(t5);
    xsi_set_current_line(65, ng0);
    t1 = (t0 + 3008U);
    t2 = *((char **)t1);
    t3 = (0 - 7);
    t17 = (t3 * -1);
    t18 = (96U * t17);
    t19 = (0 + t18);
    t1 = (t2 + t19);
    t5 = (t0 + 4960);
    t6 = (t5 + 56U);
    t9 = *((char **)t6);
    t10 = (t9 + 56U);
    t13 = *((char **)t10);
    memcpy(t13, t1, 96U);
    xsi_driver_first_trans_fast_port(t5);
    xsi_set_current_line(65, ng0);
    t1 = (t0 + 3128U);
    t2 = *((char **)t1);
    t1 = (t0 + 5024);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t9 = (t6 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 64U);
    xsi_driver_first_trans_fast_port(t1);
    t1 = (t0 + 4432);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(50, ng0);
    t5 = (t0 + 8700);
    *((int *)t5) = 95;
    t6 = (t0 + 8704);
    *((int *)t6) = 0;
    t7 = 95;
    t8 = 0;

LAB6:    if (t7 >= t8)
        goto LAB7;

LAB9:
LAB4:    t1 = (t0 + 8692);
    t3 = *((int *)t1);
    t2 = (t0 + 8696);
    t4 = *((int *)t2);
    if (t3 == t4)
        goto LAB5;

LAB17:    t7 = (t3 + -1);
    t3 = t7;
    t5 = (t0 + 8692);
    *((int *)t5) = t3;
    goto LAB2;

LAB7:    xsi_set_current_line(51, ng0);
    t9 = (t0 + 2888U);
    t10 = *((char **)t9);
    t11 = *((int *)t10);
    t12 = (t11 == 128);
    if (t12 != 0)
        goto LAB10;

LAB12:
LAB11:    xsi_set_current_line(52, ng0);
    t1 = (t0 + 2768U);
    t2 = *((char **)t1);
    t11 = *((int *)t2);
    t12 = (t11 < 0);
    if (t12 != 0)
        goto LAB13;

LAB15:
LAB14:    xsi_set_current_line(53, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 2768U);
    t5 = *((char **)t1);
    t11 = *((int *)t5);
    t14 = (t11 - 127);
    t17 = (t14 * -1);
    xsi_vhdl_check_range_of_index(127, 0, -1, t11);
    t18 = (1U * t17);
    t19 = (0 + t18);
    t1 = (t2 + t19);
    t12 = *((unsigned char *)t1);
    t6 = (t0 + 3008U);
    t9 = *((char **)t6);
    t6 = (t0 + 8700);
    t15 = *((int *)t6);
    t20 = (t15 - 95);
    t21 = (t20 * -1);
    xsi_vhdl_check_range_of_index(95, 0, -1, *((int *)t6));
    t22 = (1U * t21);
    t10 = (t0 + 8692);
    t23 = *((int *)t10);
    t24 = (t23 - 7);
    t25 = (t24 * -1);
    xsi_vhdl_check_range_of_index(7, 0, -1, *((int *)t10));
    t26 = (96U * t25);
    t27 = (0 + t26);
    t28 = (t27 + t22);
    t13 = (t9 + t28);
    *((unsigned char *)t13) = t12;
    xsi_set_current_line(54, ng0);
    t1 = (t0 + 2768U);
    t2 = *((char **)t1);
    t11 = *((int *)t2);
    t14 = (t11 - 1);
    t1 = (t0 + 2768U);
    t5 = *((char **)t1);
    t1 = (t5 + 0);
    *((int *)t1) = t14;
    xsi_set_current_line(55, ng0);
    t1 = (t0 + 2888U);
    t2 = *((char **)t1);
    t11 = *((int *)t2);
    t14 = (t11 + 1);
    t1 = (t0 + 2888U);
    t5 = *((char **)t1);
    t1 = (t5 + 0);
    *((int *)t1) = t14;

LAB8:    t1 = (t0 + 8700);
    t7 = *((int *)t1);
    t2 = (t0 + 8704);
    t8 = *((int *)t2);
    if (t7 == t8)
        goto LAB9;

LAB16:    t11 = (t7 + -1);
    t7 = t11;
    t5 = (t0 + 8700);
    *((int *)t5) = t7;
    goto LAB6;

LAB10:    xsi_set_current_line(51, ng0);
    t9 = (t0 + 2768U);
    t13 = *((char **)t9);
    t14 = *((int *)t13);
    t15 = (t14 - 25);
    t9 = (t0 + 2768U);
    t16 = *((char **)t9);
    t9 = (t16 + 0);
    *((int *)t9) = t15;
    xsi_set_current_line(51, ng0);
    t1 = (t0 + 2888U);
    t2 = *((char **)t1);
    t1 = (t2 + 0);
    *((int *)t1) = 0;
    goto LAB11;

LAB13:    xsi_set_current_line(52, ng0);
    t1 = (t0 + 2768U);
    t5 = *((char **)t1);
    t14 = *((int *)t5);
    t15 = (t14 + 128);
    t1 = (t0 + 2768U);
    t6 = *((char **)t1);
    t1 = (t6 + 0);
    *((int *)t1) = t15;
    goto LAB14;

LAB19:    xsi_set_current_line(59, ng0);
    t5 = (t0 + 2888U);
    t6 = *((char **)t5);
    t7 = *((int *)t6);
    t12 = (t7 == 128);
    if (t12 != 0)
        goto LAB22;

LAB24:
LAB23:    xsi_set_current_line(60, ng0);
    t1 = (t0 + 2768U);
    t2 = *((char **)t1);
    t7 = *((int *)t2);
    t12 = (t7 < 0);
    if (t12 != 0)
        goto LAB25;

LAB27:
LAB26:    xsi_set_current_line(61, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 2768U);
    t5 = *((char **)t1);
    t7 = *((int *)t5);
    t8 = (t7 - 127);
    t17 = (t8 * -1);
    xsi_vhdl_check_range_of_index(127, 0, -1, t7);
    t18 = (1U * t17);
    t19 = (0 + t18);
    t1 = (t2 + t19);
    t12 = *((unsigned char *)t1);
    t6 = (t0 + 3128U);
    t9 = *((char **)t6);
    t6 = (t0 + 8708);
    t11 = *((int *)t6);
    t14 = (t11 - 63);
    t21 = (t14 * -1);
    xsi_vhdl_check_range_of_index(63, 0, -1, *((int *)t6));
    t22 = (1U * t21);
    t25 = (0 + t22);
    t10 = (t9 + t25);
    *((unsigned char *)t10) = t12;
    xsi_set_current_line(62, ng0);
    t1 = (t0 + 2768U);
    t2 = *((char **)t1);
    t7 = *((int *)t2);
    t8 = (t7 - 1);
    t1 = (t0 + 2768U);
    t5 = *((char **)t1);
    t1 = (t5 + 0);
    *((int *)t1) = t8;
    xsi_set_current_line(63, ng0);
    t1 = (t0 + 2888U);
    t2 = *((char **)t1);
    t7 = *((int *)t2);
    t8 = (t7 + 1);
    t1 = (t0 + 2888U);
    t5 = *((char **)t1);
    t1 = (t5 + 0);
    *((int *)t1) = t8;

LAB20:    t1 = (t0 + 8708);
    t3 = *((int *)t1);
    t2 = (t0 + 8712);
    t4 = *((int *)t2);
    if (t3 == t4)
        goto LAB21;

LAB28:    t7 = (t3 + -1);
    t3 = t7;
    t5 = (t0 + 8708);
    *((int *)t5) = t3;
    goto LAB18;

LAB22:    xsi_set_current_line(59, ng0);
    t5 = (t0 + 2768U);
    t9 = *((char **)t5);
    t8 = *((int *)t9);
    t11 = (t8 - 25);
    t5 = (t0 + 2768U);
    t10 = *((char **)t5);
    t5 = (t10 + 0);
    *((int *)t5) = t11;
    xsi_set_current_line(59, ng0);
    t1 = (t0 + 2888U);
    t2 = *((char **)t1);
    t1 = (t2 + 0);
    *((int *)t1) = 0;
    goto LAB23;

LAB25:    xsi_set_current_line(60, ng0);
    t1 = (t0 + 2768U);
    t5 = *((char **)t1);
    t8 = *((int *)t5);
    t11 = (t8 + 128);
    t1 = (t0 + 2768U);
    t6 = *((char **)t1);
    t1 = (t6 + 0);
    *((int *)t1) = t11;
    goto LAB26;

}


extern void work_a_2331319070_3212880686_init()
{
	static char *pe[] = {(void *)work_a_2331319070_3212880686_p_0};
	xsi_register_didat("work_a_2331319070_3212880686", "isim/tb_idea_isim_beh.exe.sim/work/a_2331319070_3212880686.didat");
	xsi_register_executes(pe);
}
